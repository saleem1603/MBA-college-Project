     <!-- ts intro start -->
     <!-- <section class="ts-intro-content" id="section6"> -->
         <!-- <div class="container">
            <div class="row">
               <div class="col-lg-9 p-70"> -->
                  <!-- Background Title -->
                  <!-- <div class="title-bg">
                     <h2 class="watermark-title">venue</h2>
                  </div> -->
                  <!-- Title Area -->
                  <!-- <div class="section-title-area">
                     <span class="sub-title">conference vanue</span>
                     <h2 class="section-heading">Your daily lineup. See here for everything you needs</h2>
                     <p>Influential media, entertainment & technology show inspirational speakers including game changing not just a large-scale conference, but a large educational hub on digital technologies for business, where people communicate, get inspired and find ready-made solutions.</p>
                  </div>
               </div>
               <div class="col-lg-3">
               </div>
            </div>
            <div class="row">
               <div class="col-lg-6">
                  <h2 class="column-title text-left">
                     <span>COnference Hall</span>
                     Brighton Waterfront Hotel,
                     Brighton, London
                  </h2>
                  <div class="intro-content-text">
                     <p>
									World is committed to making participation in the event a harassment free experience for everyone, regardless of level of experience, gender, gender identity and expression
							</p>
							<a href="#">www.brightonwaterfront.com</a> -->
                  <!-- </div>single intro text end -->
               <!-- </div>col end -->
               <!-- <div class="col-lg-6">
                  <div class="intro-content-img">
                        <img src="images/venue/event-hall.jpg" alt="">
                  </div> -->
               <!-- </div>col end -->
            <!-- </div>row end -->
         <!-- </div>container end
      </section> -->
      <!-- ts intro end-->