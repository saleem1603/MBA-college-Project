
 <!-- banner start-->
 <section class="hero-area" style="background: url(images/banner.jpg);" >
         <!-- Video Popup Button -->
         <!-- <div class="video-popup-btn">
          
         </div> -->
         <!-- Hero Content Area -->
         <div class="hero-content-wrapper">
            <div class="hero-content">
               <div class="title-section-area">
                  <h1 class="banner-title">
                     <span class="sub-title">   Organizes </span>
                National Conference on Innovative Management Practices and Sustainability</br>
                     in VUCA World
                  </h1>
                  
               </div>
               <br>
            
               <!-- Banner info -->
               <div class="banner-info-meta">
                  <ul>
                     <li>
                        <p><i aria-hidden="true" class="far fa-calendar-alt"></i> 29<sup>th</sup> February, 2023 </p>
                     </li>
                     <li>
                        <p><i aria-hidden="true" class="icon icon-tsplace"></i> Jamal Mohamed College, Thiruchirappali</p>
                     </li>
                  </ul>
               </div>
               <div class="button-and-social-area">
               <a href="https://docs.google.com/forms/d/e/1FAIpQLSdaoS5PNm0Ad9KYgAg2CTu_0f_vNDU5t4mbyv7rj1HJAGzIfg/viewform"
                                target="_blank" class="register-btn btn">Register Now </a>
                  <!-- Social Icon -->
                  <ul class="social-icons">
                     <li>
                        <a href="https://www.facebook.com/jamalcollegetry/" target="_blank"><i class="icon icon-facebook"></i></a>
                     </li>
                     <li>
                        <a href="https://twitter.com/i/flow/login?redirect_after_login=%2FJamalCollege" target="_blank"><i class="icon icon-twitter"></i></a>
                     </li>
                     <li>
                        <a href="https://www.instagram.com/jamalcollege_try/" target="_blank"><i class="icon icon-instagram"></i></a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>

         


      </section>
      <!-- banner end-->
    